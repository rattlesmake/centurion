def test_repeat_head(args):
	print("head")

def test_repeat_body(args):
	#if (Selo() ~= nil) then return -1 end;
	print("body")	
	#return 0;
    
def test_repeat_foot(args):
	print("foot")
    

