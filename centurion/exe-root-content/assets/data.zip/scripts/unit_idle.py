def unit_idle_condition(args):
    return True
    
def unit_idle_body(args):
	#if (this == nil) then 
	#	return;
	#end
	#this:Stop();
    print('unit_idle_body')
