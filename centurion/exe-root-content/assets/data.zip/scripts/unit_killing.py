def unit_killing_condition(args):
    return True
    
def unit_killing_body(args):
    this = args['this']
    print("unit_killing_body")